# E-Commerce Order Management – Business Analysis Portfolio

This package contains a portfolio-ready Business Analyst case study based on the supplied resume project.

Files:
- Ecommerce_Order_Management_BA_Portfolio.docx — complete portfolio case study
- BA_Order_Analysis_Workbook.xlsx — synthetic sample order data, KPI summary, and requirement traceability
- sample_order_data.csv — synthetic sample data

The sample data is synthetic and is included only to demonstrate analysis/reporting structure.
